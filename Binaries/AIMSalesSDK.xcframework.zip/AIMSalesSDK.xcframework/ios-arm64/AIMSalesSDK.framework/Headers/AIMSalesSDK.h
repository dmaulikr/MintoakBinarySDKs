//
//  AIMSalesSDK.h
//  AIMSalesSDK
//
//  Created by Trupti Kadecha on 27/03/23.
//  Copyright © 2023 Chaitanya Soni. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for AIMSalesSDK.
FOUNDATION_EXPORT double AIMSalesSDKVersionNumber;

//! Project version string for AIMSalesSDK.
FOUNDATION_EXPORT const unsigned char AIMSalesSDKVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <AIMSalesSDK/PublicHeader.h>


