//
//  SSLHookCheck.h
//  NetWorker
//
//  Created by Maulik on 12/05/23.
//  Copyright © 2023 Chaitanya Soni. All rights reserved.
//

#ifndef SSLHookCheck_h
#define SSLHookCheck_h

#include <stdio.h>
#include <stdbool.h>
int isSSLHooked(void);
#endif /* SSLHookCheck_h */
