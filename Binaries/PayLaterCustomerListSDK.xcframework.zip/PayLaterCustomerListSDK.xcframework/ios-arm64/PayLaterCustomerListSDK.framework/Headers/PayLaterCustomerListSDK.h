//
//  PayLaterCustomerListSDK.h
//  PayLaterCustomerListSDK
//
//  Created by Mayank on 15/06/21.
//  Copyright © 2021 Chaitanya Soni. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for PayLaterCustomerListSDK.
FOUNDATION_EXPORT double PayLaterCustomerListSDKVersionNumber;

//! Project version string for PayLaterCustomerListSDK.
FOUNDATION_EXPORT const unsigned char PayLaterCustomerListSDKVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <PayLaterCustomerListSDK/PublicHeader.h>


