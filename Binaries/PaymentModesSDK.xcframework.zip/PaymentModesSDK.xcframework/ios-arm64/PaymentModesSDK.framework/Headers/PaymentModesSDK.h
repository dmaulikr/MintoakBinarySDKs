//
//  PaymentModesSDK.h
//  PaymentModesSDK
//
//  Created by Chaitanya Soni on 05/03/21.
//  Copyright © 2021 Chaitanya Soni. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for PaymentModesSDK.
FOUNDATION_EXPORT double PaymentModesSDKVersionNumber;

//! Project version string for PaymentModesSDK.
FOUNDATION_EXPORT const unsigned char PaymentModesSDKVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <PaymentModesSDK/PublicHeader.h>


